package com.cookandroid.splash;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.Toast;

public class Act_Btn3_ZeroWasteTest2 extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.btn3_zerowastetest2);

        Button Yes = (Button) findViewById(R.id.Yes);
        Button No = (Button) findViewById(R.id.No);

        Intent intent = getIntent();

        String result = intent.getStringExtra("wpqkf");
        int getInt = getIntent().getIntExtra("int_key", 0);


        if (getInt == 100) {
            Toast.makeText(getApplicationContext(), result, Toast.LENGTH_SHORT).show();
        }


    }
}

