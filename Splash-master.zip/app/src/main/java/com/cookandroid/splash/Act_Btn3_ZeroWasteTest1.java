package com.cookandroid.splash;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class Act_Btn3_ZeroWasteTest1 extends Activity {


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.btn3_zerowastetest1);

        Button Yes = (Button) findViewById(R.id.Yes);
        Button No = (Button) findViewById(R.id.No);

        double a = 100;


        Yes.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(), Act_Btn3_ZeroWasteTest2.class);
                intent.putExtra("wpqkf", "제발 넘어가주세요");
                intent.putExtra("int_key", 100);
                startActivity(intent);

            }
        });

        No.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(), Act_Btn3_ZeroWasteTest2.class);
                intent.putExtra("wpqkf", "제발 넘어가주세요");
                startActivity(intent);
            }
        });
    }


}