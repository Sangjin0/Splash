package com.cookandroid.splash;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class Act_Btn1 extends Activity {
    Button oneday_Button;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.active_button1);

        oneday_Button = (Button) findViewById(R.id.oneday_Button);

        oneday_Button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(), Act_Btn1_Map.class);
                startActivity(intent);
            }
        });
    }
}
