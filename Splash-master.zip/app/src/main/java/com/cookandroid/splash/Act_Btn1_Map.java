package com.cookandroid.splash;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;


public class Act_Btn1_Map extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.btn1_map);
    }
}
