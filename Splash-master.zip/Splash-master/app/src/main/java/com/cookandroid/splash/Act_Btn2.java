package com.cookandroid.splash;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class Act_Btn2 extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.btn2);

        Button Offline_Button= (Button)findViewById(R.id.Offline_Button);

        Offline_Button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(), Act_Btn2_OffLine.class);
                startActivity(intent);
            }
        });
    }


}
