package com.cookandroid.splash;

import android.app.Activity;
import android.os.Bundle;

public class Act_Btn2_OffLine_Almang extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.btn2_offline_almang);

    }


}
